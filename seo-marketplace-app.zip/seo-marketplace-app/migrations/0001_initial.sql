-- Migration number: 0001 	 2025-04-18
-- SEO Wildberries App Database Schema

-- Удаление существующих таблиц (если они существуют)
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS api_keys;
DROP TABLE IF EXISTS prompts;
DROP TABLE IF EXISTS marketplaces;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS seo_history;
DROP TABLE IF EXISTS activity_logs;
DROP TABLE IF EXISTS seo_trends;

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT,
  is_admin BOOLEAN NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME
);

-- Таблица маркетплейсов
CREATE TABLE IF NOT EXISTS marketplaces (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  api_url TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Таблица API-ключей пользователей
CREATE TABLE IF NOT EXISTS api_keys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  marketplace_id INTEGER,
  key_type TEXT NOT NULL, -- 'wildberries', 'ozon', 'yandex_market', 'chatgpt'
  api_key TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (marketplace_id) REFERENCES marketplaces(id) ON DELETE SET NULL
);

-- Таблица пользовательских промптов
CREATE TABLE IF NOT EXISTS prompts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  marketplace_id INTEGER NOT NULL,
  prompt_text TEXT NOT NULL,
  is_default BOOLEAN NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (marketplace_id) REFERENCES marketplaces(id) ON DELETE CASCADE
);

-- Таблица товаров
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  marketplace_id INTEGER NOT NULL,
  article TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  keywords TEXT,
  category TEXT,
  additional_data TEXT, -- JSON с дополнительными данными о товаре
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (marketplace_id) REFERENCES marketplaces(id) ON DELETE CASCADE,
  UNIQUE(user_id, marketplace_id, article)
);

-- Таблица истории SEO-изменений
CREATE TABLE IF NOT EXISTS seo_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  old_name TEXT,
  new_name TEXT,
  old_description TEXT,
  new_description TEXT,
  old_keywords TEXT,
  new_keywords TEXT,
  prompt_id INTEGER,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  applied_at DATETIME,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (prompt_id) REFERENCES prompts(id) ON DELETE SET NULL
);

-- Таблица журнала активности
CREATE TABLE IF NOT EXISTS activity_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  action_type TEXT NOT NULL, -- 'login', 'product_update', 'api_key_update', 'prompt_update', etc.
  description TEXT NOT NULL,
  ip_address TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Таблица SEO-трендов и тенденций
CREATE TABLE IF NOT EXISTS seo_trends (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  marketplace_id INTEGER NOT NULL,
  category TEXT,
  trend_data TEXT NOT NULL, -- JSON с данными о трендах
  source TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (marketplace_id) REFERENCES marketplaces(id) ON DELETE CASCADE
);

-- Начальные данные для маркетплейсов
INSERT INTO marketplaces (name, api_url) VALUES 
  ('Wildberries', 'https://suppliers-api.wildberries.ru'),
  ('Ozon', 'https://api-seller.ozon.ru'),
  ('Yandex Market', 'https://api.partner.market.yandex.ru');

-- Создание индексов для оптимизации запросов
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_api_keys_user_id ON api_keys(user_id);
CREATE INDEX idx_api_keys_key_type ON api_keys(key_type);
CREATE INDEX idx_prompts_user_id ON prompts(user_id);
CREATE INDEX idx_products_user_id ON products(user_id);
CREATE INDEX idx_products_article ON products(article);
CREATE INDEX idx_seo_history_product_id ON seo_history(product_id);
CREATE INDEX idx_activity_logs_user_id ON activity_logs(user_id);
CREATE INDEX idx_activity_logs_created_at ON activity_logs(created_at);
CREATE INDEX idx_seo_trends_marketplace_id ON seo_trends(marketplace_id);

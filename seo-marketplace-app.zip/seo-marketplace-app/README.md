# SEO-приложение для маркетплейсов

Веб-приложение для SEO-анализа и обновления карточек товаров на маркетплейсах Wildberries, Озон и Яндекс Маркет.

## Возможности

- Многопользовательская система с авторизацией
- Управление API-ключами для разных маркетплейсов и ChatGPT
- Выгрузка списка товаров из маркетплейсов
- Анализ и оптимизация SEO с помощью ChatGPT
- Настраиваемые промпты для каждого пользователя
- Обновление карточек товаров одним нажатием
- Журнал всех действий и изменений
- Адаптивный дизайн для мобильных устройств

## Установка

1. Клонируйте репозиторий:
```bash
git clone https://github.com/your-username/seo-marketplace-app.git
cd seo-marketplace-app
```

2. Установите зависимости:
```bash
npm install
```

3. Создайте файл `.env.local` со следующим содержимым:
```
NEXTAUTH_SECRET=ваш_секретный_ключ
NEXTAUTH_URL=http://localhost:3000
```

4. Запустите миграции базы данных:
```bash
npx wrangler d1 execute DB --local --file=./migrations/0001_initial.sql
```

5. Запустите приложение в режиме разработки:
```bash
npm run dev
```

## Развертывание на Cloudflare Pages

Следуйте инструкциям в файле [video-instruction-script.md](https://github.com/your-username/seo-marketplace-app/blob/main/video-instruction-script.md) для подробного руководства по развертыванию на Cloudflare Pages.

## Технологии

- **Frontend**: Next.js, React, Tailwind CSS
- **Backend**: Next.js API Routes, Cloudflare Workers
- **База данных**: Cloudflare D1 (SQLite)
- **Аутентификация**: NextAuth.js

## Структура проекта

- `src/app/` - Страницы и маршруты Next.js
- `src/components/` - Компоненты React
- `src/lib/` - Вспомогательные функции и утилиты
- `migrations/` - SQL-миграции для базы данных
- `public/` - Статические файлы

## Лицензия

MIT

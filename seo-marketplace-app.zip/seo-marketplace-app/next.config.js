/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  experimental: {
    serverActions: true,
  },
  images: {
    domains: ['images.wbstatic.net', 'cdn-images.ozon.ru', 'avatars.mds.yandex.net'],
  },
};

module.exports = nextConfig;

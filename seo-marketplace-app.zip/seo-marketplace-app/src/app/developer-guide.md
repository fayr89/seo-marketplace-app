# Руководство разработчика

## Структура проекта

Проект построен на основе Next.js с использованием App Router и организован следующим образом:

```
seo-wildberries-app/
├── migrations/             # Миграции базы данных D1
├── public/                 # Статические файлы
├── src/
│   ├── app/                # Маршруты приложения
│   │   ├── api/            # API-маршруты
│   │   ├── auth/           # Страницы аутентификации
│   │   ├── admin/          # Административная панель
│   │   ├── dashboard/      # Панель управления
│   │   └── ...
│   ├── components/         # Многоразовые компоненты
│   ├── hooks/              # Пользовательские хуки React
│   ├── lib/                # Утилиты и вспомогательные функции
│   └── ...
├── .env.local              # Локальные переменные окружения
├── next.config.js          # Конфигурация Next.js
├── package.json            # Зависимости проекта
├── tailwind.config.js      # Конфигурация Tailwind CSS
└── wrangler.toml           # Конфигурация Cloudflare Workers
```

## Технологический стек

- **Frontend**: Next.js, React, Tailwind CSS
- **Backend**: Next.js API Routes, Cloudflare Workers
- **База данных**: Cloudflare D1 (SQLite)
- **Аутентификация**: NextAuth.js
- **Стилизация**: Tailwind CSS
- **Деплой**: Cloudflare Pages

## База данных

Схема базы данных включает следующие таблицы:

### users
```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  is_admin INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### marketplaces
```sql
CREATE TABLE marketplaces (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### api_keys
```sql
CREATE TABLE api_keys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  marketplace_id INTEGER,
  key_type TEXT NOT NULL,
  api_key TEXT NOT NULL,
  is_active INTEGER DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users (id),
  FOREIGN KEY (marketplace_id) REFERENCES marketplaces (id)
);
```

### prompts
```sql
CREATE TABLE prompts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  marketplace_id INTEGER,
  name TEXT NOT NULL,
  content TEXT NOT NULL,
  is_default INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users (id),
  FOREIGN KEY (marketplace_id) REFERENCES marketplaces (id)
);
```

### products
```sql
CREATE TABLE products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  marketplace_id INTEGER NOT NULL,
  article TEXT NOT NULL,
  nm_id TEXT,
  name TEXT NOT NULL,
  description TEXT,
  keywords TEXT,
  category TEXT,
  brand TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users (id),
  FOREIGN KEY (marketplace_id) REFERENCES marketplaces (id)
);
```

### seo_history
```sql
CREATE TABLE seo_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  old_name TEXT,
  new_name TEXT,
  old_description TEXT,
  new_description TEXT,
  old_keywords TEXT,
  new_keywords TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  applied_at TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products (id)
);
```

### activity_logs
```sql
CREATE TABLE activity_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  action_type TEXT NOT NULL,
  description TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users (id)
);
```

### seo_trends
```sql
CREATE TABLE seo_trends (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  marketplace_id INTEGER NOT NULL,
  category TEXT,
  trend_data TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (marketplace_id) REFERENCES marketplaces (id)
);
```

## API-маршруты

### Аутентификация
- `POST /api/auth/register` - Регистрация нового пользователя
- `GET/POST /api/auth/[...nextauth]` - Маршруты NextAuth.js

### API-ключи
- `GET /api/api-keys` - Получение списка API-ключей пользователя
- `POST /api/api-keys/save` - Сохранение нового API-ключа
- `POST /api/api-keys/toggle-status` - Активация/деактивация API-ключа

### Товары
- `GET /api/products/list` - Получение списка товаров из Wildberries
- `GET /api/products/details` - Получение детальной информации о товаре
- `POST /api/products/update` - Обновление товара в Wildberries
- `GET /api/products/user-products` - Получение списка товаров пользователя

### Промпты
- `GET /api/prompts/list` - Получение списка промптов пользователя
- `POST /api/prompts/create` - Создание нового промпта
- `POST /api/prompts/update` - Обновление существующего промпта

### ChatGPT
- `POST /api/chatgpt/generate-seo` - Генерация SEO-рекомендаций

### История SEO
- `GET /api/seo-history` - Получение истории изменений SEO для товара

### Журнал активности
- `GET /api/activity-logs` - Получение журнала активности пользователя

### Административные маршруты
- `GET /api/admin/users` - Получение списка пользователей
- `POST /api/admin/users/update-admin` - Обновление статуса администратора

## Аутентификация

Аутентификация реализована с использованием NextAuth.js с провайдером учетных данных (Credentials Provider). Пароли хранятся в зашифрованном виде с использованием bcrypt.

```typescript
// src/app/api/auth/[...nextauth]/route.ts
import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { getCloudflareContext } from "@/lib/cloudflare";
import bcrypt from "bcryptjs";

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        // Логика авторизации
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      // Обработка JWT-токена
    },
    async session({ session, token }) {
      // Обработка сессии
    }
  },
  pages: {
    signIn: "/auth/login",
  },
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 дней
  },
  secret: process.env.NEXTAUTH_SECRET,
};
```

## Интеграция с API Wildberries

Интеграция с API Wildberries реализована через следующие функции:

```typescript
// Получение списка товаров
async function getWildberriesProducts(apiKey: string) {
  const response = await fetch('https://suppliers-api.wildberries.ru/api/v2/supplier/stocks', {
    method: 'GET',
    headers: {
      'Authorization': apiKey,
      'Content-Type': 'application/json'
    }
  });
  
  if (!response.ok) {
    throw new Error(`Ошибка API Wildberries: ${response.status}`);
  }
  
  return await response.json();
}

// Получение информации о товаре
async function getWildberriesProductDetails(apiKey: string, nmId: string) {
  const response = await fetch(`https://suppliers-api.wildberries.ru/content/v1/cards/filter?filter={"nmID":${nmId}}`, {
    method: 'GET',
    headers: {
      'Authorization': apiKey,
      'Content-Type': 'application/json'
    }
  });
  
  if (!response.ok) {
    throw new Error(`Ошибка API Wildberries: ${response.status}`);
  }
  
  return await response.json();
}

// Обновление карточки товара
async function updateWildberriesProduct(apiKey: string, data: any) {
  const response = await fetch('https://suppliers-api.wildberries.ru/content/v1/cards/update', {
    method: 'POST',
    headers: {
      'Authorization': apiKey,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  });
  
  if (!response.ok) {
    throw new Error(`Ошибка API Wildberries: ${response.status}`);
  }
  
  return await response.json();
}
```

## Интеграция с API ChatGPT

Интеграция с API ChatGPT реализована через следующую функцию:

```typescript
async function generateSeoWithChatGPT(apiKey: string, prompt: string) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: 'Вы - эксперт по SEO-оптимизации для маркетплейсов.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 2000
    })
  });
  
  if (!response.ok) {
    throw new Error(`Ошибка API ChatGPT: ${response.status}`);
  }
  
  const data = await response.json();
  return data.choices[0].message.content;
}
```

## Компоненты пользовательского интерфейса

Основные компоненты пользовательского интерфейса:

- `AuthMiddleware` - Компонент для защиты маршрутов от неавторизованного доступа
- `DashboardLayout` - Макет панели управления с навигацией
- `ProductCard` - Карточка товара для отображения в списке
- `SeoComparison` - Компонент для сравнения текущих и оптимизированных SEO-параметров
- `PromptEditor` - Редактор промптов с поддержкой плейсхолдеров
- `ActivityLogItem` - Элемент журнала активности

## Стилизация

Приложение использует Tailwind CSS для стилизации с дополнительными пользовательскими классами в стиле ИКЕА:

```css
/* ИКЕА стиль */
.ikea-btn {
  @apply px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-200;
}

.ikea-card {
  @apply bg-white shadow-md rounded-lg overflow-hidden;
}

.ikea-input {
  @apply w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500;
}
```

## Развертывание

Приложение можно развернуть на Cloudflare Pages:

1. Настройте проект в Cloudflare Pages
2. Подключите репозиторий GitHub
3. Настройте переменные окружения:
   - `NEXTAUTH_SECRET`
   - `NEXTAUTH_URL`
4. Настройте интеграцию с Cloudflare D1 для базы данных

## Расширение функциональности

### Добавление нового маркетплейса

1. Добавьте новую запись в таблицу `marketplaces`
2. Создайте интеграцию с API нового маркетплейса
3. Добавьте поддержку нового типа API-ключа
4. Обновите интерфейс для работы с новым маркетплейсом

### Добавление новых функций

1. Массовое обновление товаров
2. Аналитика эффективности SEO-оптимизации
3. Система уведомлений
4. Экспорт данных в различные форматы

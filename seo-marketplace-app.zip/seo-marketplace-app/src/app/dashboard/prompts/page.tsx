'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import AuthMiddleware from '@/components/auth-middleware';
import Link from 'next/link';

interface Marketplace {
  id: number;
  name: string;
}

interface Prompt {
  id: number;
  prompt_text: string;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export default function PromptsPage() {
  const { data: session } = useSession();
  const [marketplaces, setMarketplaces] = useState<Marketplace[]>([]);
  const [selectedMarketplace, setSelectedMarketplace] = useState<number | null>(null);
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Состояние для нового промпта
  const [newPromptText, setNewPromptText] = useState('');
  const [isDefault, setIsDefault] = useState(false);
  const [creatingPrompt, setCreatingPrompt] = useState(false);
  
  // Состояние для редактирования промпта
  const [editingPromptId, setEditingPromptId] = useState<number | null>(null);
  const [editPromptText, setEditPromptText] = useState('');
  const [editIsDefault, setEditIsDefault] = useState(false);
  const [updatingPrompt, setUpdatingPrompt] = useState(false);

  useEffect(() => {
    const fetchMarketplaces = async () => {
      try {
        const response = await fetch('/api/marketplaces');
        if (!response.ok) {
          throw new Error('Ошибка при загрузке маркетплейсов');
        }
        const data = await response.json();
        setMarketplaces(data.marketplaces);
        
        if (data.marketplaces.length > 0) {
          setSelectedMarketplace(data.marketplaces[0].id);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка');
      }
    };

    fetchMarketplaces();
  }, []);

  useEffect(() => {
    if (!selectedMarketplace) return;
    
    const fetchPrompts = async () => {
      setLoading(true);
      setError('');
      
      try {
        const response = await fetch(`/api/prompts/list?marketplaceId=${selectedMarketplace}`);
        
        if (!response.ok) {
          throw new Error('Ошибка при загрузке промптов');
        }
        
        const data = await response.json();
        setPrompts(data.prompts || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка при загрузке промптов');
      } finally {
        setLoading(false);
      }
    };
    
    fetchPrompts();
  }, [selectedMarketplace]);

  const handleMarketplaceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedMarketplace(Number(e.target.value));
  };

  const handleCreatePrompt = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedMarketplace || !newPromptText.trim()) {
      setError('Текст промпта не может быть пустым');
      return;
    }
    
    setError('');
    setSuccess('');
    setCreatingPrompt(true);
    
    try {
      const response = await fetch('/api/prompts/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          marketplaceId: selectedMarketplace,
          promptText: newPromptText,
          isDefault
        }),
      });
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Ошибка при создании промпта');
      }
      
      // Обновляем список промптов
      const promptsResponse = await fetch(`/api/prompts/list?marketplaceId=${selectedMarketplace}`);
      const promptsData = await promptsResponse.json();
      setPrompts(promptsData.prompts || []);
      
      // Сбрасываем форму
      setNewPromptText('');
      setIsDefault(false);
      
      setSuccess('Промпт успешно создан');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка при создании промпта');
    } finally {
      setCreatingPrompt(false);
    }
  };

  const handleEditPrompt = (prompt: Prompt) => {
    setEditingPromptId(prompt.id);
    setEditPromptText(prompt.prompt_text);
    setEditIsDefault(prompt.is_default);
  };

  const handleCancelEdit = () => {
    setEditingPromptId(null);
    setEditPromptText('');
    setEditIsDefault(false);
  };

  const handleUpdatePrompt = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingPromptId || !editPromptText.trim()) {
      setError('Текст промпта не может быть пустым');
      return;
    }
    
    setError('');
    setSuccess('');
    setUpdatingPrompt(true);
    
    try {
      const response = await fetch('/api/prompts/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          promptId: editingPromptId,
          promptText: editPromptText,
          isDefault: editIsDefault
        }),
      });
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Ошибка при обновлении промпта');
      }
      
      // Обновляем список промптов
      const promptsResponse = await fetch(`/api/prompts/list?marketplaceId=${selectedMarketplace}`);
      const promptsData = await promptsResponse.json();
      setPrompts(promptsData.prompts || []);
      
      // Сбрасываем форму редактирования
      setEditingPromptId(null);
      setEditPromptText('');
      setEditIsDefault(false);
      
      setSuccess('Промпт успешно обновлен');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка при обновлении промпта');
    } finally {
      setUpdatingPrompt(false);
    }
  };

  return (
    <AuthMiddleware>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Управление промптами</h1>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}
        
        {success && (
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            {success}
          </div>
        )}
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-4 md:mb-0">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Маркетплейс
                </label>
                <select
                  value={selectedMarketplace || ''}
                  onChange={handleMarketplaceChange}
                  className="w-full md:w-auto px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  {marketplaces.map((marketplace) => (
                    <option key={marketplace.id} value={marketplace.id}>
                      {marketplace.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          
          {loading ? (
            <div className="px-6 py-12 text-center">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <div className="p-6">
              <div className="mb-8">
                <h2 className="text-lg font-semibold mb-4">Создать новый промпт</h2>
                <form onSubmit={handleCreatePrompt}>
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Текст промпта
                    </label>
                    <textarea
                      value={newPromptText}
                      onChange={(e) => setNewPromptText(e.target.value)}
                      placeholder="Введите текст промпта. Используйте {title}, {description}, {keywords}, {category} для подстановки данных о товаре."
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 h-40"
                      required
                    />
                  </div>
                  
                  <div className="mb-4 flex items-center">
                    <input
                      type="checkbox"
                      id="isDefault"
                      checked={isDefault}
                      onChange={(e) => setIsDefault(e.target.checked)}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <label htmlFor="isDefault" className="ml-2 block text-sm text-gray-900">
                      Использовать по умолчанию
                    </label>
                  </div>
                  
                  <button
                    type="submit"
                    disabled={creatingPrompt}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                  >
                    {creatingPrompt ? 'Создание...' : 'Создать промпт'}
                  </button>
                </form>
              </div>
              
              <div>
                <h2 className="text-lg font-semibold mb-4">Существующие промпты</h2>
                
                {prompts.length === 0 ? (
                  <div className="text-center text-gray-500 py-4">
                    У вас пока нет промптов для этого маркетплейса
                  </div>
                ) : (
                  <div className="space-y-6">
                    {prompts.map((prompt) => (
                      <div 
                        key={prompt.id} 
                        className={`border rounded-md p-4 ${prompt.is_default ? 'border-blue-500 bg-blue-50' : 'border-gray-200'}`}
                      >
                        {editingPromptId === prompt.id ? (
                          <form onSubmit={handleUpdatePrompt}>
                            <div className="mb-4">
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                Текст промпта
                              </label>
                              <textarea
                                value={editPromptText}
                                onChange={(e) => setEditPromptText(e.target.value)}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 h-40"
                                required
                              />
                            </div>
                            
                            <div className="mb-4 flex items-center">
                              <input
                                type="checkbox"
                                id={`editIsDefault-${prompt.id}`}
                                checked={editIsDefault}
                                onChange={(e) => setEditIsDefault(e.target.checked)}
                                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                              />
                              <label htmlFor={`editIsDefault-${prompt.id}`} className="ml-2 block text-sm text-gray-900">
                                Использовать по умолчанию
                              </label>
                            </div>
                            
                            <div className="flex space-x-2">
                              <button
                                type="submit"
                                disabled={updatingPrompt}
                                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"
                              >
                                {updatingPrompt ? 'Сохранение...' : 'Сохранить'}
                              </button>
                              <button
                                type="button"
                                onClick={handleCancelEdit}
                                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
                              >
                                Отмена
                              </button>
                            </div>
                          </form>
                        ) : (
                          <>
                            <div className="flex justify-between items-start mb-2">
                              <div className="flex items-center">
                                {prompt.is_default && (
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 mr-2">
                                    По умолчанию
                                  </span>
                                )}
                                <span className="text-sm text-gray-500">
                                  Создан: {new Date(prompt.created_at).toLocaleString()}
                                </span>
                              </div>
                              <button
                                onClick={() => handleEditPrompt(prompt)}
                                className="text-blue-600 hover:text-blue-800"
                              >
                                Редактировать
                              </button>
                            </div>
                            <div className="whitespace-pre-wrap bg-gray-50 p-3 rounded-md border border-gray-200">
                              {prompt.prompt_text}
                            </div>
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold">Справка по использованию промптов</h2>
          </div>
          <div className="p-6">
            <p className="mb-4">
              Промпты используются для генерации SEO-рекомендаций с помощью ChatGPT. Вы можете создавать собственные промпты и настраивать их под свои потребности.
            </p>
            
            <h3 className="text-md font-semibold mb-2">Плейсхолдеры для подстановки данных о товаре:</h3>
            <ul className="list-disc pl-5 mb-4 space-y-1">
              <li><code className="bg-gray-100 px-1 py-0.5 rounded">{'{title}'}</code> - текущее название товара</li>
              <li><code className="bg-gray-100 px-1 py-0.5 rounded">{'{description}'}</code> - текущее описание товара</li>
              <li><code className="bg-gray-100 px-1 py-0.5 rounded">{'{keywords}'}</code> - текущие ключевые слова</li>
              <li><code className="bg-gray-100 px-1 py-0.5 rounded">{'{category}'}</code> - категория товара</li>
            </ul>
            
            <h3 className="text-md font-semibold mb-2">Рекомендации по составлению промптов:</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Указывайте четкие инструкции для ChatGPT</li>
              <li>Определяйте формат ответа (например, разделение на название, описание и ключевые слова)</li>
              <li>Указывайте ограничения по длине (название до 100 символов, описание до 1000 символов)</li>
              <li>Добавляйте специфические требования к SEO для вашей ниши</li>
              <li>Просите учитывать тренды поиска и использовать ключевые слова разной частотности</li>
            </ul>
          </div>
        </div>
      </div>
    </AuthMiddleware>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import AuthMiddleware from '@/components/auth-middleware';
import Link from 'next/link';

interface Marketplace {
  id: number;
  name: string;
}

interface Product {
  nmId: string;
  title: string;
  description: string;
  tags: string[];
  subjectName: string;
  updatedAt: string;
}

export default function ProductsPage() {
  const { data: session } = useSession();
  const [marketplaces, setMarketplaces] = useState<Marketplace[]>([]);
  const [selectedMarketplace, setSelectedMarketplace] = useState<number | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [hasApiKey, setHasApiKey] = useState(false);
  const productsPerPage = 10;

  useEffect(() => {
    const fetchMarketplaces = async () => {
      try {
        const response = await fetch('/api/marketplaces');
        if (!response.ok) {
          throw new Error('Ошибка при загрузке маркетплейсов');
        }
        const data = await response.json();
        setMarketplaces(data.marketplaces);
        
        if (data.marketplaces.length > 0) {
          setSelectedMarketplace(data.marketplaces[0].id);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка');
      }
    };

    fetchMarketplaces();
  }, []);

  useEffect(() => {
    if (!selectedMarketplace) return;
    
    const checkApiKey = async () => {
      try {
        const response = await fetch('/api/api-keys');
        if (!response.ok) {
          throw new Error('Ошибка при проверке API-ключей');
        }
        const data = await response.json();
        
        // Проверяем наличие активного ключа для выбранного маркетплейса
        const hasKey = data.apiKeys.some(
          (key: any) => key.marketplace_id === selectedMarketplace && key.is_active
        );
        
        setHasApiKey(hasKey);
        
        if (hasKey) {
          fetchProducts();
        } else {
          setLoading(false);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка');
        setLoading(false);
      }
    };
    
    const fetchProducts = async () => {
      setLoading(true);
      setError('');
      
      try {
        const response = await fetch('/api/products/list', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            marketplaceId: selectedMarketplace,
            limit: 100
          }),
        });
        
        if (!response.ok) {
          throw new Error('Ошибка при загрузке товаров');
        }
        
        const data = await response.json();
        setProducts(data.cards || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка при загрузке товаров');
      } finally {
        setLoading(false);
      }
    };
    
    checkApiKey();
  }, [selectedMarketplace]);

  const handleMarketplaceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedMarketplace(Number(e.target.value));
    setCurrentPage(1);
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  const filteredProducts = products.filter(product => 
    product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.nmId.toString().includes(searchTerm) ||
    product.subjectName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const indexOfLastProduct = currentPage * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);
  const totalPages = Math.ceil(filteredProducts.length / productsPerPage);

  const paginate = (pageNumber: number) => setCurrentPage(pageNumber);

  return (
    <AuthMiddleware>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Список товаров</h1>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-4 md:mb-0">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Маркетплейс
                </label>
                <select
                  value={selectedMarketplace || ''}
                  onChange={handleMarketplaceChange}
                  className="w-full md:w-auto px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  {marketplaces.map((marketplace) => (
                    <option key={marketplace.id} value={marketplace.id}>
                      {marketplace.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="w-full md:w-1/2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Поиск
                </label>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={handleSearch}
                  placeholder="Поиск по названию, артикулу или категории"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          </div>
          
          {!hasApiKey ? (
            <div className="px-6 py-12 text-center">
              <div className="text-gray-500 mb-4">
                Для получения списка товаров необходимо добавить API-ключ для выбранного маркетплейса
              </div>
              <Link 
                href="/dashboard/api-keys" 
                className="inline-block px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Добавить API-ключ
              </Link>
            </div>
          ) : loading ? (
            <div className="px-6 py-12 text-center">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : products.length === 0 ? (
            <div className="px-6 py-12 text-center text-gray-500">
              Товары не найдены
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Артикул
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Название
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Категория
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Действия
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {currentProducts.map((product) => (
                      <tr key={product.nmId}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {product.nmId}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                          {product.title}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {product.subjectName || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <Link
                            href={`/dashboard/products/${product.nmId}?marketplaceId=${selectedMarketplace}`}
                            className="text-blue-600 hover:text-blue-900 mr-4"
                          >
                            Просмотр
                          </Link>
                          <Link
                            href={`/dashboard/products/${product.nmId}/optimize?marketplaceId=${selectedMarketplace}`}
                            className="text-green-600 hover:text-green-900"
                          >
                            Оптимизировать SEO
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              {totalPages > 1 && (
                <div className="px-6 py-4 flex items-center justify-between border-t border-gray-200">
                  <div>
                    <p className="text-sm text-gray-700">
                      Показано <span className="font-medium">{indexOfFirstProduct + 1}</span> - <span className="font-medium">
                        {Math.min(indexOfLastProduct, filteredProducts.length)}
                      </span> из <span className="font-medium">{filteredProducts.length}</span> товаров
                    </p>
                  </div>
                  <div>
                    <nav className="flex items-center">
                      <button
                        onClick={() => paginate(currentPage - 1)}
                        disabled={currentPage === 1}
                        className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Назад
                      </button>
                      {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
                        const pageNumber = currentPage > 3 ? 
                          (currentPage - 3 + i + 1 > totalPages ? totalPages - 5 + i + 1 : currentPage - 3 + i + 1) : 
                          i + 1;
                        
                        if (pageNumber <= 0 || pageNumber > totalPages) return null;
                        
                        return (
                          <button
                            key={pageNumber}
                            onClick={() => paginate(pageNumber)}
                            className={`relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium ${
                              currentPage === pageNumber ? 'text-blue-600 bg-blue-50' : 'text-gray-700 hover:bg-gray-50'
                            }`}
                          >
                            {pageNumber}
                          </button>
                        );
                      })}
                      <button
                        onClick={() => paginate(currentPage + 1)}
                        disabled={currentPage === totalPages}
                        className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Вперед
                      </button>
                    </nav>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </AuthMiddleware>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import AuthMiddleware from '@/components/auth-middleware';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

interface ProductDetails {
  id: number;
  nmId: string;
  name: string;
  description: string;
  keywords: string;
  category: string;
  details: any;
}

interface Prompt {
  id: number;
  prompt_text: string;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export default function ProductOptimizePage({ 
  params 
}: { 
  params: { nmId: string } 
}) {
  const router = useRouter();
  const { data: session } = useSession();
  const [product, setProduct] = useState<ProductDetails | null>(null);
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [selectedPromptId, setSelectedPromptId] = useState<number | null>(null);
  const [generatedSeo, setGeneratedSeo] = useState<string | null>(null);
  const [parsedSeo, setParsedSeo] = useState<{
    title: string;
    description: string;
    keywords: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [marketplaceId, setMarketplaceId] = useState<number | null>(null);

  useEffect(() => {
    // Получаем marketplaceId из URL
    const searchParams = new URLSearchParams(window.location.search);
    const marketplaceIdParam = searchParams.get('marketplaceId');
    
    if (!marketplaceIdParam) {
      setError('ID маркетплейса не указан');
      setLoading(false);
      return;
    }
    
    setMarketplaceId(Number(marketplaceIdParam));
    
    const fetchData = async () => {
      try {
        // Получаем информацию о товаре
        const productResponse = await fetch('/api/products/details', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            marketplaceId: Number(marketplaceIdParam),
            nmId: params.nmId
          }),
        });
        
        if (!productResponse.ok) {
          throw new Error('Ошибка при загрузке информации о товаре');
        }
        
        const productData = await productResponse.json();
        setProduct(productData.product);
        
        // Получаем промпты пользователя
        const promptsResponse = await fetch(`/api/prompts/list?marketplaceId=${marketplaceIdParam}`);
        
        if (!promptsResponse.ok) {
          throw new Error('Ошибка при загрузке промптов');
        }
        
        const promptsData = await promptsResponse.json();
        setPrompts(promptsData.prompts);
        
        // Устанавливаем промпт по умолчанию, если он есть
        const defaultPrompt = promptsData.prompts.find((p: Prompt) => p.is_default);
        if (defaultPrompt) {
          setSelectedPromptId(defaultPrompt.id);
        } else if (promptsData.prompts.length > 0) {
          setSelectedPromptId(promptsData.prompts[0].id);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка при загрузке данных');
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [params.nmId]);

  const handleGenerateSeo = async () => {
    if (!product) return;
    
    setError('');
    setSuccess('');
    setGenerating(true);
    
    try {
      const response = await fetch('/api/chatgpt/generate-seo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productData: product,
          promptId: selectedPromptId
        }),
      });
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Ошибка при генерации SEO-рекомендаций');
      }
      
      const data = await response.json();
      setGeneratedSeo(data.generatedContent);
      
      // Парсим сгенерированный контент
      try {
        const titleMatch = data.generatedContent.match(/1\.\s*Название[^:]*:\s*([^\n]+)/i);
        const descriptionMatch = data.generatedContent.match(/2\.\s*Описание[^:]*:\s*([\s\S]+?)(?=3\.|$)/i);
        const keywordsMatch = data.generatedContent.match(/3\.\s*Ключевые слова[^:]*:\s*([^\n]+)/i);
        
        if (titleMatch && descriptionMatch && keywordsMatch) {
          setParsedSeo({
            title: titleMatch[1].trim(),
            description: descriptionMatch[1].trim(),
            keywords: keywordsMatch[1].trim()
          });
        } else {
          console.warn('Не удалось распарсить сгенерированный контент');
        }
      } catch (parseError) {
        console.error('Ошибка при парсинге сгенерированного контента:', parseError);
      }
      
      setSuccess('SEO-рекомендации успешно сгенерированы');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка при генерации SEO-рекомендаций');
    } finally {
      setGenerating(false);
    }
  };

  const handleUpdateProduct = async () => {
    if (!product || !parsedSeo || !marketplaceId) return;
    
    setError('');
    setSuccess('');
    setUpdating(true);
    
    try {
      const response = await fetch('/api/products/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          marketplaceId,
          nmId: product.nmId,
          title: parsedSeo.title,
          description: parsedSeo.description,
          tags: parsedSeo.keywords
        }),
      });
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Ошибка при обновлении товара');
      }
      
      setSuccess('Товар успешно обновлен');
      
      // Обновляем информацию о товаре
      setTimeout(() => {
        router.push(`/dashboard/products/${product.nmId}?marketplaceId=${marketplaceId}`);
      }, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка при обновлении товара');
    } finally {
      setUpdating(false);
    }
  };

  return (
    <AuthMiddleware>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6 flex items-center">
          <Link 
            href={`/dashboard/products/${params.nmId}?marketplaceId=${marketplaceId}`}
            className="text-blue-600 hover:text-blue-800 mr-4"
          >
            ← Назад к товару
          </Link>
          <h1 className="text-2xl font-bold">Оптимизация SEO</h1>
        </div>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}
        
        {success && (
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            {success}
          </div>
        )}
        
        {loading ? (
          <div className="bg-white shadow-md rounded-lg p-8 text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : product ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold">Текущие SEO-параметры</h2>
              </div>
              
              <div className="p-6">
                <div className="mb-4">
                  <p className="text-sm font-medium text-gray-500 mb-1">Название</p>
                  <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                    {product.name}
                  </div>
                </div>
                
                <div className="mb-4">
                  <p className="text-sm font-medium text-gray-500 mb-1">Описание</p>
                  <div className="p-3 bg-gray-50 border border-gray-200 rounded-md whitespace-pre-wrap h-48 overflow-y-auto">
                    {product.description || 'Описание отсутствует'}
                  </div>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-500 mb-1">Ключевые слова</p>
                  <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                    {product.keywords ? (
                      <div className="flex flex-wrap gap-2">
                        {product.keywords.split(',').map((keyword, index) => (
                          <span 
                            key={index} 
                            className="inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded-md text-sm"
                          >
                            {keyword.trim()}
                          </span>
                        ))}
                      </div>
                    ) : (
                      'Ключевые слова отсутствуют'
                    )}
                  </div>
                </div>
              </div>
              
              <div className="px-6 py-4 border-t border-gray-200">
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Выберите промпт для генерации
                  </label>
                  <select
                    value={selectedPromptId || ''}
                    onChange={(e) => setSelectedPromptId(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    disabled={generating}
                  >
                    {prompts.length === 0 ? (
                      <option value="">Нет доступных промптов</option>
                    ) : (
                      prompts.map((prompt) => (
                        <option key={prompt.id} value={prompt.id}>
                          {prompt.is_default ? '(По умолчанию) ' : ''}
                          {prompt.prompt_text.substring(0, 50)}...
                        </option>
                      ))
                    )}
                  </select>
                </div>
                
                <button
                  onClick={handleGenerateSeo}
                  disabled={generating || !selectedPromptId}
                  className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                >
                  {generating ? 'Генерация...' : 'Сгенерировать SEO-рекомендации'}
                </button>
                
                <div className="mt-2 text-center">
                  <Link
                    href="/dashboard/prompts"
                    className="text-sm text-blue-600 hover:text-blue-800"
                  >
                    Управление промптами
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold">Оптимизированные SEO-параметры</h2>
              </div>
              
              {generatedSeo ? (
                <div className="p-6">
                  {parsedSeo ? (
                    <>
                      <div className="mb-4">
                        <p className="text-sm font-medium text-gray-500 mb-1">Название</p>
                        <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                          {parsedSeo.title}
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-sm font-medium text-gray-500 mb-1">Описание</p>
                        <div className="p-3 bg-gray-50 border border-gray-200 rounded-md whitespace-pre-wrap h-48 overflow-y-auto">
                          {parsedSeo.description}
                        </div>
                      </div>
                      
                      <div className="mb-6">
                        <p className="text-sm font-medium text-gray-500 mb-1">Ключевые слова</p>
                        <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                          <div className="flex flex-wrap gap-2">
                            {parsedSeo.keywords.split(',').map((keyword, index) => (
                              <span 
                                key={index} 
                                className="inline-block bg-green-100 text-green-800 px-2 py-1 rounded-md text-sm"
                              >
                                {keyword.trim()}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      <button
                        onClick={handleUpdateProduct}
                        disabled={updating}
                        className="w-full px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50"
                      >
                        {updating ? 'Обновление...' : 'Обновить товар в Wildberries'}
                      </button>
                    </>
                  ) : (
                    <div className="p-6 whitespace-pre-wrap">
                      <p className="mb-4 text-sm text-gray-500">Исходный ответ ChatGPT:</p>
                      {generatedSeo}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-6 text-center text-gray-500">
                  Сгенерируйте SEO-рекомендации, чтобы увидеть оптимизированные параметры
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white shadow-md rounded-lg p-8 text-center text-gray-500">
            Товар не найден
          </div>
        )}
      </div>
    </AuthMiddleware>
  );
}

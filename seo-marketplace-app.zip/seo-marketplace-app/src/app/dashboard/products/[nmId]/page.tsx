'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import AuthMiddleware from '@/components/auth-middleware';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

interface ProductDetails {
  id: number;
  nmId: string;
  name: string;
  description: string;
  keywords: string;
  category: string;
  details: any;
}

export default function ProductDetailsPage({ 
  params 
}: { 
  params: { nmId: string } 
}) {
  const router = useRouter();
  const { data: session } = useSession();
  const [product, setProduct] = useState<ProductDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [marketplaceId, setMarketplaceId] = useState<number | null>(null);

  useEffect(() => {
    // Получаем marketplaceId из URL
    const searchParams = new URLSearchParams(window.location.search);
    const marketplaceIdParam = searchParams.get('marketplaceId');
    
    if (!marketplaceIdParam) {
      setError('ID маркетплейса не указан');
      setLoading(false);
      return;
    }
    
    setMarketplaceId(Number(marketplaceIdParam));
    
    const fetchProductDetails = async () => {
      try {
        const response = await fetch('/api/products/details', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            marketplaceId: Number(marketplaceIdParam),
            nmId: params.nmId
          }),
        });
        
        if (!response.ok) {
          throw new Error('Ошибка при загрузке информации о товаре');
        }
        
        const data = await response.json();
        setProduct(data.product);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка при загрузке информации о товаре');
      } finally {
        setLoading(false);
      }
    };
    
    fetchProductDetails();
  }, [params.nmId]);

  const handleOptimizeClick = () => {
    if (marketplaceId) {
      router.push(`/dashboard/products/${params.nmId}/optimize?marketplaceId=${marketplaceId}`);
    }
  };

  return (
    <AuthMiddleware>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6 flex items-center">
          <Link 
            href="/dashboard/products" 
            className="text-blue-600 hover:text-blue-800 mr-4"
          >
            ← Назад к списку товаров
          </Link>
          <h1 className="text-2xl font-bold">Информация о товаре</h1>
        </div>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}
        
        {loading ? (
          <div className="bg-white shadow-md rounded-lg p-8 text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : product ? (
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-lg font-semibold">Артикул: {product.nmId}</h2>
              <button
                onClick={handleOptimizeClick}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
              >
                Оптимизировать SEO
              </button>
            </div>
            
            <div className="p-6">
              <div className="mb-6">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Основная информация</h3>
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-500">Категория</p>
                      <p className="mt-1">{product.category || 'Не указана'}</p>
                    </div>
                    {product.details.brand && (
                      <div>
                        <p className="text-sm font-medium text-gray-500">Бренд</p>
                        <p className="mt-1">{product.details.brand}</p>
                      </div>
                    )}
                    {product.details.vendorCode && (
                      <div>
                        <p className="text-sm font-medium text-gray-500">Артикул продавца</p>
                        <p className="mt-1">{product.details.vendorCode}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-medium text-gray-900 mb-2">SEO-параметры</h3>
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-500">Название</p>
                    <p className="mt-1 p-2 bg-white border border-gray-200 rounded-md">{product.name}</p>
                  </div>
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-500">Описание</p>
                    <div className="mt-1 p-2 bg-white border border-gray-200 rounded-md whitespace-pre-wrap">
                      {product.description || 'Описание отсутствует'}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Ключевые слова</p>
                    <div className="mt-1 flex flex-wrap gap-2">
                      {product.keywords ? (
                        product.keywords.split(',').map((keyword, index) => (
                          <span 
                            key={index} 
                            className="inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded-md text-sm"
                          >
                            {keyword.trim()}
                          </span>
                        ))
                      ) : (
                        <p className="text-gray-500">Ключевые слова отсутствуют</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              {product.details.characteristics && product.details.characteristics.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Характеристики</h3>
                  <div className="bg-gray-50 p-4 rounded-md">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {product.details.characteristics.map((char: any, index: number) => (
                        <div key={index}>
                          <p className="text-sm font-medium text-gray-500">{char.name}</p>
                          <p className="mt-1">{char.value}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white shadow-md rounded-lg p-8 text-center text-gray-500">
            Товар не найден
          </div>
        )}
      </div>
    </AuthMiddleware>
  );
}

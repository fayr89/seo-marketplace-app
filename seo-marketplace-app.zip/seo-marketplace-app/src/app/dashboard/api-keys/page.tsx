'use client';

import { useState, useEffect } from 'react';
import AuthMiddleware from '@/components/auth-middleware';
import { useSession } from 'next-auth/react';

interface ApiKey {
  id: number;
  key_type: string;
  api_key: string;
  is_active: boolean;
  marketplace_id: number | null;
  marketplace_name: string | null;
}

interface Marketplace {
  id: number;
  name: string;
}

export default function ApiKeysPage() {
  const { data: session } = useSession();
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [marketplaces, setMarketplaces] = useState<Marketplace[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [newKeyType, setNewKeyType] = useState('chatgpt');
  const [newKeyValue, setNewKeyValue] = useState('');
  const [selectedMarketplace, setSelectedMarketplace] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Получаем список маркетплейсов
        const marketplacesResponse = await fetch('/api/marketplaces');
        if (!marketplacesResponse.ok) {
          throw new Error('Ошибка при загрузке маркетплейсов');
        }
        const marketplacesData = await marketplacesResponse.json();
        setMarketplaces(marketplacesData.marketplaces);

        // Получаем API-ключи пользователя
        const apiKeysResponse = await fetch('/api/api-keys');
        if (!apiKeysResponse.ok) {
          throw new Error('Ошибка при загрузке API-ключей');
        }
        const apiKeysData = await apiKeysResponse.json();
        setApiKeys(apiKeysData.apiKeys);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSaveKey = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    setIsSaving(true);

    try {
      const marketplaceId = newKeyType === 'chatgpt' ? null : selectedMarketplace;
      
      const response = await fetch('/api/api-keys/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          keyType: newKeyType,
          apiKey: newKeyValue,
          marketplaceId
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Ошибка при сохранении API-ключа');
      }

      const data = await response.json();
      
      // Обновляем список ключей
      const updatedKeys = [...apiKeys];
      const existingKeyIndex = updatedKeys.findIndex(
        key => key.key_type === newKeyType && key.marketplace_id === marketplaceId
      );
      
      if (existingKeyIndex >= 0) {
        updatedKeys[existingKeyIndex] = data.apiKey;
      } else {
        updatedKeys.push(data.apiKey);
      }
      
      setApiKeys(updatedKeys);
      setNewKeyValue('');
      setSuccessMessage('API-ключ успешно сохранен');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка при сохранении API-ключа');
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleKeyStatus = async (keyId: number, currentStatus: boolean) => {
    try {
      const response = await fetch('/api/api-keys/toggle-status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          keyId,
          isActive: !currentStatus
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Ошибка при изменении статуса API-ключа');
      }

      const data = await response.json();
      
      // Обновляем список ключей
      setApiKeys(apiKeys.map(key => 
        key.id === keyId ? { ...key, is_active: !currentStatus } : key
      ));
      
      setSuccessMessage('Статус API-ключа успешно изменен');
      
      // Скрываем сообщение об успехе через 3 секунды
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка при изменении статуса API-ключа');
    }
  };

  const getKeyTypeLabel = (keyType: string, marketplaceName: string | null) => {
    if (keyType === 'chatgpt') return 'ChatGPT';
    return marketplaceName || 'Неизвестный маркетплейс';
  };

  const maskApiKey = (key: string) => {
    if (key.length <= 8) return '••••••••';
    return key.substring(0, 4) + '••••••••' + key.substring(key.length - 4);
  };

  return (
    <AuthMiddleware>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Управление API-ключами</h1>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}
        
        {successMessage && (
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            {successMessage}
          </div>
        )}
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold">Добавить новый API-ключ</h2>
          </div>
          
          <form onSubmit={handleSaveKey} className="px-6 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Тип ключа
                </label>
                <select
                  value={newKeyType}
                  onChange={(e) => setNewKeyType(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="chatgpt">ChatGPT</option>
                  <option value="marketplace">Маркетплейс</option>
                </select>
              </div>
              
              {newKeyType === 'marketplace' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Маркетплейс
                  </label>
                  <select
                    value={selectedMarketplace || ''}
                    onChange={(e) => setSelectedMarketplace(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Выберите маркетплейс</option>
                    {marketplaces.map((marketplace) => (
                      <option key={marketplace.id} value={marketplace.id}>
                        {marketplace.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Значение API-ключа
              </label>
              <input
                type="text"
                value={newKeyValue}
                onChange={(e) => setNewKeyValue(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Введите API-ключ"
                required
              />
            </div>
            
            <button
              type="submit"
              disabled={isSaving || (newKeyType === 'marketplace' && !selectedMarketplace)}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
            >
              {isSaving ? 'Сохранение...' : 'Сохранить ключ'}
            </button>
          </form>
        </div>
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold">Ваши API-ключи</h2>
          </div>
          
          {loading ? (
            <div className="px-6 py-4 text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : apiKeys.length === 0 ? (
            <div className="px-6 py-4 text-center text-gray-500">
              У вас пока нет сохраненных API-ключей
            </div>
          ) : (
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Сервис
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    API-ключ
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Статус
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Действия
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {apiKeys.map((key) => (
                  <tr key={key.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {getKeyTypeLabel(key.key_type, key.marketplace_name)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">
                      {maskApiKey(key.api_key)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        key.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {key.is_active ? 'Активен' : 'Неактивен'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button
                        onClick={() => handleToggleKeyStatus(key.id, key.is_active)}
                        className={`px-3 py-1 rounded text-white text-xs ${
                          key.is_active ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'
                        }`}
                      >
                        {key.is_active ? 'Деактивировать' : 'Активировать'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </AuthMiddleware>
  );
}

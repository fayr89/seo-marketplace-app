'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import AuthMiddleware from '@/components/auth-middleware';
import Link from 'next/link';

interface SeoHistory {
  id: number;
  product_id: number;
  old_name: string;
  new_name: string;
  old_description: string;
  new_description: string;
  old_keywords: string;
  new_keywords: string;
  created_at: string;
  applied_at: string | null;
}

interface Product {
  id: number;
  article: string;
  name: string;
  category: string;
  updated_at: string;
}

export default function SeoHistoryPage() {
  const { data: session } = useSession();
  const [products, setProducts] = useState<Product[]>([]);
  const [seoHistory, setSeoHistory] = useState<SeoHistory[]>([]);
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const itemsPerPage = 5;

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch('/api/products/user-products');
        if (!response.ok) {
          throw new Error('Ошибка при загрузке товаров');
        }
        const data = await response.json();
        setProducts(data.products);
        
        if (data.products.length > 0) {
          setSelectedProductId(data.products[0].id);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка');
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  useEffect(() => {
    if (!selectedProductId) return;
    
    const fetchSeoHistory = async () => {
      setLoading(true);
      setError('');
      
      try {
        const response = await fetch(`/api/seo-history?productId=${selectedProductId}&page=${currentPage}&limit=${itemsPerPage}`);
        
        if (!response.ok) {
          throw new Error('Ошибка при загрузке истории SEO');
        }
        
        const data = await response.json();
        setSeoHistory(data.history);
        setTotalPages(Math.ceil(data.total / itemsPerPage));
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка при загрузке истории SEO');
      } finally {
        setLoading(false);
      }
    };
    
    fetchSeoHistory();
  }, [selectedProductId, currentPage]);

  const handleProductChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedProductId(Number(e.target.value));
    setCurrentPage(1);
  };

  const paginate = (pageNumber: number) => setCurrentPage(pageNumber);

  // Функция для подсветки различий в тексте
  const highlightDifferences = (oldText: string, newText: string) => {
    if (!oldText || !newText) return { oldHighlighted: oldText, newHighlighted: newText };
    
    const oldWords = oldText.split(' ');
    const newWords = newText.split(' ');
    
    const oldHighlighted = oldWords.map(word => 
      !newWords.includes(word) ? `<span class="bg-red-100">${word}</span>` : word
    ).join(' ');
    
    const newHighlighted = newWords.map(word => 
      !oldWords.includes(word) ? `<span class="bg-green-100">${word}</span>` : word
    ).join(' ');
    
    return { oldHighlighted, newHighlighted };
  };

  return (
    <AuthMiddleware>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">История изменений SEO</h1>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-4 md:mb-0">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Выберите товар
                </label>
                <select
                  value={selectedProductId || ''}
                  onChange={handleProductChange}
                  className="w-full md:w-auto px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  {products.map((product) => (
                    <option key={product.id} value={product.id}>
                      {product.article} - {product.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          
          {loading ? (
            <div className="px-6 py-12 text-center">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : seoHistory.length === 0 ? (
            <div className="px-6 py-12 text-center text-gray-500">
              История изменений SEO для выбранного товара отсутствует
            </div>
          ) : (
            <div className="p-6">
              <div className="space-y-8">
                {seoHistory.map((item) => {
                  const titleDiff = highlightDifferences(item.old_name, item.new_name);
                  const descriptionDiff = highlightDifferences(item.old_description, item.new_description);
                  const keywordsDiff = highlightDifferences(item.old_keywords, item.new_keywords);
                  
                  return (
                    <div key={item.id} className="border border-gray-200 rounded-lg overflow-hidden">
                      <div className="bg-gray-50 px-4 py-2 border-b border-gray-200 flex justify-between items-center">
                        <div>
                          <span className="text-sm font-medium text-gray-700">
                            Изменено: {new Date(item.created_at).toLocaleString()}
                          </span>
                          {item.applied_at && (
                            <span className="ml-4 text-sm text-gray-500">
                              Применено: {new Date(item.applied_at).toLocaleString()}
                            </span>
                          )}
                        </div>
                      </div>
                      
                      <div className="p-4">
                        <div className="mb-6">
                          <h3 className="text-md font-semibold mb-2">Название</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-1">Было:</p>
                              <div 
                                className="p-3 bg-gray-50 border border-gray-200 rounded-md"
                                dangerouslySetInnerHTML={{ __html: titleDiff.oldHighlighted }}
                              />
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-1">Стало:</p>
                              <div 
                                className="p-3 bg-gray-50 border border-gray-200 rounded-md"
                                dangerouslySetInnerHTML={{ __html: titleDiff.newHighlighted }}
                              />
                            </div>
                          </div>
                        </div>
                        
                        <div className="mb-6">
                          <h3 className="text-md font-semibold mb-2">Описание</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-1">Было:</p>
                              <div 
                                className="p-3 bg-gray-50 border border-gray-200 rounded-md h-40 overflow-y-auto whitespace-pre-wrap"
                                dangerouslySetInnerHTML={{ __html: descriptionDiff.oldHighlighted }}
                              />
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-1">Стало:</p>
                              <div 
                                className="p-3 bg-gray-50 border border-gray-200 rounded-md h-40 overflow-y-auto whitespace-pre-wrap"
                                dangerouslySetInnerHTML={{ __html: descriptionDiff.newHighlighted }}
                              />
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="text-md font-semibold mb-2">Ключевые слова</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-1">Было:</p>
                              <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                                {item.old_keywords ? (
                                  <div className="flex flex-wrap gap-2">
                                    {item.old_keywords.split(',').map((keyword, index) => (
                                      <span 
                                        key={index} 
                                        className={`inline-block px-2 py-1 rounded-md text-sm ${
                                          !item.new_keywords.includes(keyword.trim()) 
                                            ? 'bg-red-100 text-red-800' 
                                            : 'bg-blue-100 text-blue-800'
                                        }`}
                                      >
                                        {keyword.trim()}
                                      </span>
                                    ))}
                                  </div>
                                ) : (
                                  <span className="text-gray-500">Отсутствуют</span>
                                )}
                              </div>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-1">Стало:</p>
                              <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                                {item.new_keywords ? (
                                  <div className="flex flex-wrap gap-2">
                                    {item.new_keywords.split(',').map((keyword, index) => (
                                      <span 
                                        key={index} 
                                        className={`inline-block px-2 py-1 rounded-md text-sm ${
                                          !item.old_keywords.includes(keyword.trim()) 
                                            ? 'bg-green-100 text-green-800' 
                                            : 'bg-blue-100 text-blue-800'
                                        }`}
                                      >
                                        {keyword.trim()}
                                      </span>
                                    ))}
                                  </div>
                                ) : (
                                  <span className="text-gray-500">Отсутствуют</span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              {totalPages > 1 && (
                <div className="mt-6 flex items-center justify-center">
                  <nav className="flex items-center">
                    <button
                      onClick={() => paginate(currentPage - 1)}
                      disabled={currentPage === 1}
                      className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Назад
                    </button>
                    {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
                      const pageNumber = currentPage > 3 ? 
                        (currentPage - 3 + i + 1 > totalPages ? totalPages - 5 + i + 1 : currentPage - 3 + i + 1) : 
                        i + 1;
                      
                      if (pageNumber <= 0 || pageNumber > totalPages) return null;
                      
                      return (
                        <button
                          key={pageNumber}
                          onClick={() => paginate(pageNumber)}
                          className={`relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium ${
                            currentPage === pageNumber ? 'text-blue-600 bg-blue-50' : 'text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          {pageNumber}
                        </button>
                      );
                    })}
                    <button
                      onClick={() => paginate(currentPage + 1)}
                      disabled={currentPage === totalPages}
                      className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Вперед
                    </button>
                  </nav>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </AuthMiddleware>
  );
}

export const dynamic = 'force-dynamic';

import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Журнал активности | SEO Wildberries',
  description: 'Журнал активности пользователя в системе',
}

export default function ActivityLogsLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div>
      {children}
    </div>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

interface ActivityLog {
  id: number;
  user_id: number;
  action_type: string;
  description: string;
  created_at: string;
}

export default function ActivityLogsPage() {
  const { data: session, status } = useSession();
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filterType, setFilterType] = useState('all');
  const itemsPerPage = 20;

  useEffect(() => {
    // Проверяем, что сессия загружена и пользователь авторизован
    if (status === 'loading') return;
    
    if (status === 'unauthenticated') {
      window.location.href = '/auth/login';
      return;
    }
    
    const fetchActivityLogs = async () => {
      setLoading(true);
      setError('');
      
      try {
        const response = await fetch(`/api/activity-logs?page=${currentPage}&limit=${itemsPerPage}&type=${filterType}`);
        
        if (!response.ok) {
          throw new Error('Ошибка при загрузке журнала активности');
        }
        
        const data = await response.json();
        setActivityLogs(data.logs);
        setTotalPages(Math.ceil(data.total / itemsPerPage));
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка при загрузке журнала активности');
      } finally {
        setLoading(false);
      }
    };
    
    fetchActivityLogs();
  }, [currentPage, filterType, status]);

  const paginate = (pageNumber: number) => setCurrentPage(pageNumber);

  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilterType(e.target.value);
    setCurrentPage(1);
  };

  const getActionTypeLabel = (actionType: string) => {
    const actionTypes: Record<string, string> = {
      'login': 'Вход в систему',
      'logout': 'Выход из системы',
      'register': 'Регистрация',
      'api_key_create': 'Создание API-ключа',
      'api_key_update': 'Обновление API-ключа',
      'product_list_fetch': 'Получение списка товаров',
      'product_details_fetch': 'Получение информации о товаре',
      'product_update': 'Обновление товара',
      'chatgpt_seo_generation': 'Генерация SEO-рекомендаций',
      'prompt_create': 'Создание промпта',
      'prompt_update': 'Обновление промпта'
    };
    
    return actionTypes[actionType] || actionType;
  };

  const getActionTypeColor = (actionType: string) => {
    const actionColors: Record<string, string> = {
      'login': 'bg-blue-100 text-blue-800',
      'logout': 'bg-gray-100 text-gray-800',
      'register': 'bg-purple-100 text-purple-800',
      'api_key_create': 'bg-yellow-100 text-yellow-800',
      'api_key_update': 'bg-yellow-100 text-yellow-800',
      'product_list_fetch': 'bg-indigo-100 text-indigo-800',
      'product_details_fetch': 'bg-indigo-100 text-indigo-800',
      'product_update': 'bg-green-100 text-green-800',
      'chatgpt_seo_generation': 'bg-pink-100 text-pink-800',
      'prompt_create': 'bg-orange-100 text-orange-800',
      'prompt_update': 'bg-orange-100 text-orange-800'
    };
    
    return actionColors[actionType] || 'bg-gray-100 text-gray-800';
  };

  // Показываем загрузку, пока статус сессии не определен
  if (status === 'loading') {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  // Если пользователь не авторизован, перенаправляем на страницу входа
  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Журнал активности</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="mb-4 md:mb-0">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Фильтр по типу действия
              </label>
              <select
                value={filterType}
                onChange={handleFilterChange}
                className="w-full md:w-auto px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">Все действия</option>
                <option value="login">Вход в систему</option>
                <option value="product_update">Обновление товара</option>
                <option value="chatgpt_seo_generation">Генерация SEO</option>
                <option value="prompt">Управление промптами</option>
                <option value="api_key">Управление API-ключами</option>
              </select>
            </div>
          </div>
        </div>
        
        {loading ? (
          <div className="px-6 py-12 text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : activityLogs.length === 0 ? (
          <div className="px-6 py-12 text-center text-gray-500">
            Журнал активности пуст
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Дата и время
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Тип действия
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Описание
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {activityLogs.map((log) => (
                  <tr key={log.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(log.created_at).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getActionTypeColor(log.action_type)}`}>
                        {getActionTypeLabel(log.action_type)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {log.description}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        
        {totalPages > 1 && (
          <div className="px-6 py-4 flex items-center justify-between border-t border-gray-200">
            <div>
              <p className="text-sm text-gray-700">
                Страница <span className="font-medium">{currentPage}</span> из <span className="font-medium">{totalPages}</span>
              </p>
            </div>
            <div>
              <nav className="flex items-center">
                <button
                  onClick={() => paginate(currentPage - 1)}
                  disabled={currentPage === 1}
                  className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Назад
                </button>
                {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
                  const pageNumber = currentPage > 3 ? 
                    (currentPage - 3 + i + 1 > totalPages ? totalPages - 5 + i + 1 : currentPage - 3 + i + 1) : 
                    i + 1;
                  
                  if (pageNumber <= 0 || pageNumber > totalPages) return null;
                  
                  return (
                    <button
                      key={pageNumber}
                      onClick={() => paginate(pageNumber)}
                      className={`relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium ${
                        currentPage === pageNumber ? 'text-blue-600 bg-blue-50' : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {pageNumber}
                    </button>
                  );
                })}
                <button
                  onClick={() => paginate(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Вперед
                </button>
              </nav>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

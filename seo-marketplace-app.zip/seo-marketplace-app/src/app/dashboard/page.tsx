'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import AuthMiddleware from '@/components/auth-middleware';
import Link from 'next/link';

export default function DashboardPage() {
  const { data: session } = useSession();
  const [stats, setStats] = useState({
    totalProducts: 0,
    optimizedProducts: 0,
    apiKeysCount: 0,
    promptsCount: 0
  });
  const [recentActivity, setRecentActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      setError('');
      
      try {
        // Получаем статистику
        const statsResponse = await fetch('/api/dashboard/stats');
        if (!statsResponse.ok) {
          throw new Error('Ошибка при загрузке статистики');
        }
        const statsData = await statsResponse.json();
        setStats(statsData);
        
        // Получаем последние действия
        const activityResponse = await fetch('/api/activity-logs?page=1&limit=5');
        if (!activityResponse.ok) {
          throw new Error('Ошибка при загрузке журнала активности');
        }
        const activityData = await activityResponse.json();
        setRecentActivity(activityData.logs);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Произошла ошибка');
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);

  const getActionTypeLabel = (actionType) => {
    const actionTypes = {
      'login': 'Вход в систему',
      'logout': 'Выход из системы',
      'register': 'Регистрация',
      'api_key_create': 'Создание API-ключа',
      'api_key_update': 'Обновление API-ключа',
      'product_list_fetch': 'Получение списка товаров',
      'product_details_fetch': 'Получение информации о товаре',
      'product_update': 'Обновление товара',
      'chatgpt_seo_generation': 'Генерация SEO-рекомендаций',
      'prompt_create': 'Создание промпта',
      'prompt_update': 'Обновление промпта'
    };
    
    return actionTypes[actionType] || actionType;
  };

  return (
    <AuthMiddleware>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Панель управления</h1>
        
        {error && (
          <div className="ikea-alert-error">
            {error}
          </div>
        )}
        
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <>
            {/* Статистика */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="ikea-card">
                <div className="ikea-card-body">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                      <svg className="h-8 w-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                      </svg>
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Всего товаров</p>
                      <p className="text-2xl font-semibold text-gray-900">{stats.totalProducts}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="ikea-card">
                <div className="ikea-card-body">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-green-100 text-green-600">
                      <svg className="h-8 w-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Оптимизировано</p>
                      <p className="text-2xl font-semibold text-gray-900">{stats.optimizedProducts}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="ikea-card">
                <div className="ikea-card-body">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-yellow-100 text-yellow-600">
                      <svg className="h-8 w-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                      </svg>
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">API-ключи</p>
                      <p className="text-2xl font-semibold text-gray-900">{stats.apiKeysCount}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="ikea-card">
                <div className="ikea-card-body">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-purple-100 text-purple-600">
                      <svg className="h-8 w-8" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Промпты</p>
                      <p className="text-2xl font-semibold text-gray-900">{stats.promptsCount}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Быстрые действия */}
            <div className="ikea-card mb-8">
              <div className="ikea-card-header">
                <h2 className="text-lg font-semibold">Быстрые действия</h2>
              </div>
              <div className="ikea-card-body">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Link href="/dashboard/products" className="ikea-btn text-center">
                    Просмотреть товары
                  </Link>
                  <Link href="/dashboard/api-keys" className="ikea-btn text-center">
                    Управление API-ключами
                  </Link>
                  <Link href="/dashboard/prompts" className="ikea-btn text-center">
                    Настроить промпты
                  </Link>
                </div>
              </div>
            </div>
            
            {/* Последние действия */}
            <div className="ikea-card">
              <div className="ikea-card-header">
                <h2 className="text-lg font-semibold">Последние действия</h2>
              </div>
              <div className="ikea-card-body">
                {recentActivity.length === 0 ? (
                  <p className="text-center text-gray-500 py-4">Нет недавних действий</p>
                ) : (
                  <div className="space-y-4">
                    {recentActivity.map((activity) => (
                      <div key={activity.id} className="flex items-start">
                        <div className="flex-shrink-0">
                          <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <svg className="h-5 w-5 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                          </div>
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-900">
                            {getActionTypeLabel(activity.action_type)}
                          </p>
                          <p className="text-sm text-gray-500">
                            {activity.description}
                          </p>
                          <p className="text-xs text-gray-400 mt-1">
                            {new Date(activity.created_at).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                <div className="mt-6 text-center">
                  <Link href="/dashboard/activity-logs" className="ikea-btn-secondary">
                    Просмотреть все действия
                  </Link>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </AuthMiddleware>
  );
}

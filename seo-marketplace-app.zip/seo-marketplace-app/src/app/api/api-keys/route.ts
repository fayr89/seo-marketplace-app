import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    const apiKeys = await env.DB.prepare(`
      SELECT ak.id, ak.key_type, ak.api_key, ak.is_active, m.name as marketplace_name, m.id as marketplace_id
      FROM api_keys ak
      LEFT JOIN marketplaces m ON ak.marketplace_id = m.id
      WHERE ak.user_id = ?
      ORDER BY ak.key_type, m.name
    `).bind(userId).all();

    return NextResponse.json({ apiKeys: apiKeys.results });
  } catch (error) {
    console.error('Error fetching API keys:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении API-ключей' },
      { status: 500 }
    );
  }
}

import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { keyId, isActive } = await request.json();
    
    if (typeof keyId !== 'number' || typeof isActive !== 'boolean') {
      return NextResponse.json(
        { error: 'Неверные параметры запроса' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Проверяем, принадлежит ли ключ пользователю
    const apiKey = await env.DB.prepare(`
      SELECT id, key_type FROM api_keys WHERE id = ? AND user_id = ?
    `).bind(keyId, userId).first();
    
    if (!apiKey) {
      return NextResponse.json(
        { error: 'API-ключ не найден или не принадлежит пользователю' },
        { status: 404 }
      );
    }
    
    // Обновляем статус ключа
    const result = await env.DB.prepare(`
      UPDATE api_keys SET is_active = ? WHERE id = ? 
      RETURNING id, key_type, api_key, is_active, marketplace_id
    `).bind(isActive ? 1 : 0, keyId).first();

    // Логируем действие
    await env.DB.prepare(`
      INSERT INTO activity_logs (user_id, action_type, description) 
      VALUES (?, ?, ?)
    `).bind(
      userId, 
      'api_key_status_update',
      `API-ключ типа ${apiKey.key_type} ${isActive ? 'активирован' : 'деактивирован'}`
    ).run();

    return NextResponse.json({ apiKey: result });
  } catch (error) {
    console.error('Error updating API key status:', error);
    return NextResponse.json(
      { error: 'Ошибка при обновлении статуса API-ключа' },
      { status: 500 }
    );
  }
}

import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { keyType, apiKey, marketplaceId } = await request.json();
    
    if (!keyType || !apiKey) {
      return NextResponse.json(
        { error: 'Тип ключа и значение ключа обязательны' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Проверяем, существует ли уже ключ такого типа для этого пользователя и маркетплейса
    const existingKey = await env.DB.prepare(`
      SELECT id FROM api_keys 
      WHERE user_id = ? AND key_type = ? AND (marketplace_id = ? OR (marketplace_id IS NULL AND ? IS NULL))
    `).bind(userId, keyType, marketplaceId, marketplaceId).first();
    
    let result;
    
    if (existingKey) {
      // Обновляем существующий ключ
      result = await env.DB.prepare(`
        UPDATE api_keys 
        SET api_key = ?, is_active = 1 
        WHERE id = ? 
        RETURNING id, key_type, api_key, is_active, marketplace_id
      `).bind(apiKey, existingKey.id).first();
    } else {
      // Создаем новый ключ
      result = await env.DB.prepare(`
        INSERT INTO api_keys (user_id, key_type, api_key, marketplace_id, is_active) 
        VALUES (?, ?, ?, ?, 1) 
        RETURNING id, key_type, api_key, is_active, marketplace_id
      `).bind(userId, keyType, apiKey, marketplaceId).first();
    }

    // Логируем действие
    await env.DB.prepare(`
      INSERT INTO activity_logs (user_id, action_type, description) 
      VALUES (?, ?, ?)
    `).bind(
      userId, 
      existingKey ? 'api_key_update' : 'api_key_create',
      `${existingKey ? 'Обновлен' : 'Добавлен'} API-ключ типа ${keyType}`
    ).run();

    return NextResponse.json({ apiKey: result });
  } catch (error) {
    console.error('Error saving API key:', error);
    return NextResponse.json(
      { error: 'Ошибка при сохранении API-ключа' },
      { status: 500 }
    );
  }
}

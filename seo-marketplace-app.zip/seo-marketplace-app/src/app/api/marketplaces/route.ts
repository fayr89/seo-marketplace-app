import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { env } = getCloudflareContext();
    
    const marketplaces = await env.DB.prepare(`
      SELECT id, name, api_url, is_active 
      FROM marketplaces 
      WHERE is_active = 1
      ORDER BY name
    `).all();

    return NextResponse.json({ marketplaces: marketplaces.results });
  } catch (error) {
    console.error('Error fetching marketplaces:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении списка маркетплейсов' },
      { status: 500 }
    );
  }
}

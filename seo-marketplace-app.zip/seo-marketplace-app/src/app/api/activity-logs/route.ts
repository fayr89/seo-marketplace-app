import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const type = searchParams.get('type') || 'all';
    
    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Формируем условие фильтрации по типу действия
    let typeCondition = '';
    let typeParams: any[] = [];
    
    if (type !== 'all') {
      if (type === 'prompt') {
        typeCondition = 'AND (action_type LIKE ? OR action_type LIKE ?)';
        typeParams = ['prompt_create%', 'prompt_update%'];
      } else if (type === 'api_key') {
        typeCondition = 'AND (action_type LIKE ? OR action_type LIKE ?)';
        typeParams = ['api_key_create%', 'api_key_update%'];
      } else {
        typeCondition = 'AND action_type LIKE ?';
        typeParams = [`${type}%`];
      }
    }
    
    // Получаем общее количество записей для пагинации
    const totalCountQuery = `
      SELECT COUNT(*) as count 
      FROM activity_logs 
      WHERE user_id = ? ${typeCondition}
    `;
    
    const totalCountParams = [userId, ...typeParams];
    const totalCount = await env.DB.prepare(totalCountQuery).bind(...totalCountParams).first<{ count: number }>();
    
    // Получаем журнал активности с пагинацией
    const offset = (page - 1) * limit;
    
    const logsQuery = `
      SELECT id, user_id, action_type, description, created_at
      FROM activity_logs 
      WHERE user_id = ? ${typeCondition}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `;
    
    const logsParams = [userId, ...typeParams, limit, offset];
    const logs = await env.DB.prepare(logsQuery).bind(...logsParams).all();

    return NextResponse.json({
      logs: logs.results,
      total: totalCount?.count || 0,
      page,
      limit
    });
  } catch (error) {
    console.error('Error fetching activity logs:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении журнала активности' },
      { status: 500 }
    );
  }
}

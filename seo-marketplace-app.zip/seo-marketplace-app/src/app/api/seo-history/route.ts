import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const productId = searchParams.get('productId');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    
    if (!productId) {
      return NextResponse.json(
        { error: 'ID товара обязателен' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Проверяем, принадлежит ли товар пользователю
    const product = await env.DB.prepare(`
      SELECT id 
      FROM products 
      WHERE id = ? AND user_id = ?
    `).bind(productId, userId).first<{ id: number }>();
    
    if (!product) {
      return NextResponse.json(
        { error: 'Товар не найден или не принадлежит пользователю' },
        { status: 404 }
      );
    }
    
    // Получаем общее количество записей истории SEO для пагинации
    const totalCount = await env.DB.prepare(`
      SELECT COUNT(*) as count 
      FROM seo_history 
      WHERE product_id = ?
    `).bind(productId).first<{ count: number }>();
    
    // Получаем историю изменений SEO с пагинацией
    const offset = (page - 1) * limit;
    
    const history = await env.DB.prepare(`
      SELECT id, product_id, old_name, new_name, old_description, new_description, 
             old_keywords, new_keywords, created_at, applied_at
      FROM seo_history 
      WHERE product_id = ?
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `).bind(productId, limit, offset).all();

    return NextResponse.json({
      history: history.results,
      total: totalCount?.count || 0,
      page,
      limit
    });
  } catch (error) {
    console.error('Error fetching SEO history:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении истории SEO' },
      { status: 500 }
    );
  }
}

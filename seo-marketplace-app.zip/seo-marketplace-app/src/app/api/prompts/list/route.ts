import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const marketplaceId = searchParams.get('marketplaceId');
    
    if (!marketplaceId) {
      return NextResponse.json(
        { error: 'ID маркетплейса обязателен' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Получаем промпты пользователя для указанного маркетплейса
    const prompts = await env.DB.prepare(`
      SELECT id, prompt_text, is_default, created_at, updated_at
      FROM prompts 
      WHERE user_id = ? AND marketplace_id = ?
      ORDER BY is_default DESC, updated_at DESC
    `).bind(userId, marketplaceId).all();

    return NextResponse.json({ prompts: prompts.results });
  } catch (error) {
    console.error('Error fetching prompts:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении промптов' },
      { status: 500 }
    );
  }
}

import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { marketplaceId, promptText, isDefault = false } = await request.json();
    
    if (!marketplaceId || !promptText) {
      return NextResponse.json(
        { error: 'ID маркетплейса и текст промпта обязательны' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Если промпт помечен как дефолтный, сбрасываем флаг у всех других промптов пользователя для этого маркетплейса
    if (isDefault) {
      await env.DB.prepare(`
        UPDATE prompts 
        SET is_default = 0 
        WHERE user_id = ? AND marketplace_id = ?
      `).bind(userId, marketplaceId).run();
    }
    
    // Сохраняем промпт
    const result = await env.DB.prepare(`
      INSERT INTO prompts (user_id, marketplace_id, prompt_text, is_default) 
      VALUES (?, ?, ?, ?)
      RETURNING id
    `).bind(userId, marketplaceId, promptText, isDefault ? 1 : 0).first<{ id: number }>();
    
    // Логируем действие
    await env.DB.prepare(`
      INSERT INTO activity_logs (user_id, action_type, description) 
      VALUES (?, ?, ?)
    `).bind(
      userId, 
      'prompt_create',
      `Создан новый промпт для маркетплейса ID: ${marketplaceId}`
    ).run();

    return NextResponse.json({
      success: true,
      promptId: result?.id
    });
  } catch (error) {
    console.error('Error creating prompt:', error);
    return NextResponse.json(
      { error: 'Ошибка при создании промпта' },
      { status: 500 }
    );
  }
}

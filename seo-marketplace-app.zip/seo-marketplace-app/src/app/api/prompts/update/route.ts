import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { promptId, promptText, isDefault = false } = await request.json();
    
    if (!promptId || !promptText) {
      return NextResponse.json(
        { error: 'ID промпта и текст промпта обязательны' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Проверяем, принадлежит ли промпт пользователю
    const prompt = await env.DB.prepare(`
      SELECT id, marketplace_id 
      FROM prompts 
      WHERE id = ? AND user_id = ?
    `).bind(promptId, userId).first<{ id: number, marketplace_id: number }>();
    
    if (!prompt) {
      return NextResponse.json(
        { error: 'Промпт не найден или не принадлежит пользователю' },
        { status: 404 }
      );
    }
    
    // Если промпт помечен как дефолтный, сбрасываем флаг у всех других промптов пользователя для этого маркетплейса
    if (isDefault) {
      await env.DB.prepare(`
        UPDATE prompts 
        SET is_default = 0 
        WHERE user_id = ? AND marketplace_id = ?
      `).bind(userId, prompt.marketplace_id).run();
    }
    
    // Обновляем промпт
    await env.DB.prepare(`
      UPDATE prompts 
      SET prompt_text = ?, is_default = ?, updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).bind(promptText, isDefault ? 1 : 0, promptId).run();
    
    // Логируем действие
    await env.DB.prepare(`
      INSERT INTO activity_logs (user_id, action_type, description) 
      VALUES (?, ?, ?)
    `).bind(
      userId, 
      'prompt_update',
      `Обновлен промпт (ID: ${promptId})`
    ).run();

    return NextResponse.json({
      success: true,
      message: 'Промпт успешно обновлен'
    });
  } catch (error) {
    console.error('Error updating prompt:', error);
    return NextResponse.json(
      { error: 'Ошибка при обновлении промпта' },
      { status: 500 }
    );
  }
}

import { getCloudflareContext } from '@/lib/cloudflare';
import { updateUserAdmin } from '@/lib/auth/db';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user.isAdmin) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { userId, isAdmin } = await request.json();
    
    if (typeof userId !== 'number' || typeof isAdmin !== 'boolean') {
      return NextResponse.json(
        { error: 'Неверные параметры запроса' },
        { status: 400 }
      );
    }

    // Запрет на изменение собственного статуса администратора
    if (userId === Number(session.user.id)) {
      return NextResponse.json(
        { error: 'Нельзя изменить свой собственный статус администратора' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const success = await updateUserAdmin(env.DB, userId, isAdmin);

    if (!success) {
      return NextResponse.json(
        { error: 'Не удалось обновить статус администратора' },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error updating admin status:', error);
    return NextResponse.json(
      { error: 'Ошибка при обновлении статуса администратора' },
      { status: 500 }
    );
  }
}

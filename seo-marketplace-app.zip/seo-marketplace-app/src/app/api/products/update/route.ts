import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { marketplaceId, nmId, title, description, tags } = await request.json();
    
    if (!marketplaceId || !nmId || !title || !description) {
      return NextResponse.json(
        { error: 'ID маркетплейса, ID товара (nmId), название и описание обязательны' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Получаем API-ключ пользователя для Wildberries
    const apiKey = await env.DB.prepare(`
      SELECT api_key 
      FROM api_keys 
      WHERE user_id = ? AND marketplace_id = ? AND is_active = 1
    `).bind(userId, marketplaceId).first<{ api_key: string }>();
    
    if (!apiKey) {
      return NextResponse.json(
        { error: 'API-ключ для Wildberries не найден или неактивен' },
        { status: 400 }
      );
    }

    // Получаем URL API для маркетплейса
    const marketplace = await env.DB.prepare(`
      SELECT api_url 
      FROM marketplaces 
      WHERE id = ?
    `).bind(marketplaceId).first<{ api_url: string }>();
    
    if (!marketplace) {
      return NextResponse.json(
        { error: 'Маркетплейс не найден' },
        { status: 404 }
      );
    }

    // Сначала получаем текущие данные о товаре, чтобы сохранить все необходимые поля
    const detailsRequestBody = {
      settings: {
        cursor: {
          limit: 1
        }
      },
      filter: {
        nmID: [Number(nmId)]
      }
    };

    const detailsResponse = await fetch(`${marketplace.api_url}/content/v2/get/cards/list`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': apiKey.api_key
      },
      body: JSON.stringify(detailsRequestBody)
    });

    if (!detailsResponse.ok) {
      const errorData = await detailsResponse.json();
      return NextResponse.json(
        { error: `Ошибка API Wildberries при получении данных о товаре: ${JSON.stringify(errorData)}` },
        { status: detailsResponse.status }
      );
    }

    const detailsData = await detailsResponse.json();
    
    if (!detailsData.cards || detailsData.cards.length === 0) {
      return NextResponse.json(
        { error: 'Товар не найден' },
        { status: 404 }
      );
    }

    const currentCard = detailsData.cards[0];
    
    // Формируем запрос к API Wildberries для обновления товара
    // Важно: нужно включить все параметры товара, даже те, которые не меняются
    const updateCard = {
      ...currentCard,
      title: title,
      description: description,
      tags: tags ? tags.split(',').map((tag: string) => tag.trim()) : currentCard.tags
    };
    
    // Отправляем запрос к API Wildberries
    const updateResponse = await fetch(`${marketplace.api_url}/content/v2/cards/update`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': apiKey.api_key
      },
      body: JSON.stringify([updateCard])
    });

    if (!updateResponse.ok) {
      const errorData = await updateResponse.json();
      return NextResponse.json(
        { error: `Ошибка API Wildberries при обновлении товара: ${JSON.stringify(errorData)}` },
        { status: updateResponse.status }
      );
    }

    const updateData = await updateResponse.json();
    
    // Получаем информацию о товаре из базы данных
    const product = await env.DB.prepare(`
      SELECT id, name, description, keywords 
      FROM products 
      WHERE user_id = ? AND marketplace_id = ? AND article = ?
    `).bind(userId, marketplaceId, nmId.toString()).first<{ 
      id: number, 
      name: string, 
      description: string, 
      keywords: string 
    }>();
    
    if (product) {
      // Сохраняем историю изменений SEO
      await env.DB.prepare(`
        INSERT INTO seo_history (
          product_id, old_name, new_name, old_description, new_description, 
          old_keywords, new_keywords, created_at, applied_at
        ) 
        VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `).bind(
        product.id,
        product.name,
        title,
        product.description,
        description,
        product.keywords,
        tags || ''
      ).run();
      
      // Обновляем информацию о товаре в базе данных
      await env.DB.prepare(`
        UPDATE products 
        SET name = ?, description = ?, keywords = ?, updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `).bind(
        title,
        description,
        tags || '',
        product.id
      ).run();
    }

    // Логируем действие
    await env.DB.prepare(`
      INSERT INTO activity_logs (user_id, action_type, description) 
      VALUES (?, ?, ?)
    `).bind(
      userId, 
      'product_update',
      `Обновлены SEO-параметры товара Wildberries (nmID: ${nmId})`
    ).run();

    return NextResponse.json({
      success: true,
      message: 'Товар успешно обновлен',
      updateResult: updateData
    });
  } catch (error) {
    console.error('Error updating product:', error);
    return NextResponse.json(
      { error: 'Ошибка при обновлении товара' },
      { status: 500 }
    );
  }
}

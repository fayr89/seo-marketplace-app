import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { marketplaceId, nmId } = await request.json();
    
    if (!marketplaceId || !nmId) {
      return NextResponse.json(
        { error: 'ID маркетплейса и ID товара (nmId) обязательны' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Получаем API-ключ пользователя для Wildberries
    const apiKey = await env.DB.prepare(`
      SELECT api_key 
      FROM api_keys 
      WHERE user_id = ? AND marketplace_id = ? AND is_active = 1
    `).bind(userId, marketplaceId).first<{ api_key: string }>();
    
    if (!apiKey) {
      return NextResponse.json(
        { error: 'API-ключ для Wildberries не найден или неактивен' },
        { status: 400 }
      );
    }

    // Получаем URL API для маркетплейса
    const marketplace = await env.DB.prepare(`
      SELECT api_url 
      FROM marketplaces 
      WHERE id = ?
    `).bind(marketplaceId).first<{ api_url: string }>();
    
    if (!marketplace) {
      return NextResponse.json(
        { error: 'Маркетплейс не найден' },
        { status: 404 }
      );
    }

    // Формируем запрос к API Wildberries для получения детальной информации о товаре
    // Используем метод получения списка товаров с фильтром по nmId
    const requestBody = {
      settings: {
        cursor: {
          limit: 1
        }
      },
      filter: {
        nmID: [Number(nmId)]
      }
    };

    // Отправляем запрос к API Wildberries
    const response = await fetch(`${marketplace.api_url}/content/v2/get/cards/list`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': apiKey.api_key
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorData = await response.json();
      return NextResponse.json(
        { error: `Ошибка API Wildberries: ${JSON.stringify(errorData)}` },
        { status: response.status }
      );
    }

    const data = await response.json();
    
    if (!data.cards || data.cards.length === 0) {
      return NextResponse.json(
        { error: 'Товар не найден' },
        { status: 404 }
      );
    }

    const productCard = data.cards[0];
    
    // Сохраняем информацию о товаре в базу данных
    const existingProduct = await env.DB.prepare(`
      SELECT id FROM products 
      WHERE user_id = ? AND marketplace_id = ? AND article = ?
    `).bind(userId, marketplaceId, nmId.toString()).first<{ id: number }>();
    
    let productId;
    
    if (existingProduct) {
      // Обновляем существующий товар
      await env.DB.prepare(`
        UPDATE products 
        SET name = ?, description = ?, keywords = ?, additional_data = ?, updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `).bind(
        productCard.title || '',
        productCard.description || '',
        productCard.tags?.join(', ') || '',
        JSON.stringify(productCard),
        existingProduct.id
      ).run();
      
      productId = existingProduct.id;
    } else {
      // Создаем новый товар
      const result = await env.DB.prepare(`
        INSERT INTO products (user_id, marketplace_id, article, name, description, keywords, category, additional_data) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        RETURNING id
      `).bind(
        userId,
        marketplaceId,
        nmId.toString(),
        productCard.title || '',
        productCard.description || '',
        productCard.tags?.join(', ') || '',
        productCard.subjectName || '',
        JSON.stringify(productCard)
      ).first<{ id: number }>();
      
      productId = result?.id;
    }

    // Логируем действие
    await env.DB.prepare(`
      INSERT INTO activity_logs (user_id, action_type, description) 
      VALUES (?, ?, ?)
    `).bind(
      userId, 
      'product_details_fetch',
      `Получена детальная информация о товаре Wildberries (nmID: ${nmId})`
    ).run();

    return NextResponse.json({
      product: {
        id: productId,
        nmId: nmId,
        name: productCard.title || '',
        description: productCard.description || '',
        keywords: productCard.tags?.join(', ') || '',
        category: productCard.subjectName || '',
        details: productCard
      }
    });
  } catch (error) {
    console.error('Error fetching product details:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении информации о товаре' },
      { status: 500 }
    );
  }
}

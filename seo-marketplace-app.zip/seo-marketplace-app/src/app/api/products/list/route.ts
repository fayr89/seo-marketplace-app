import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { marketplaceId, limit = 100, withPhoto = -1 } = await request.json();
    
    if (!marketplaceId) {
      return NextResponse.json(
        { error: 'ID маркетплейса обязателен' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Получаем API-ключ пользователя для Wildberries
    const apiKey = await env.DB.prepare(`
      SELECT api_key 
      FROM api_keys 
      WHERE user_id = ? AND marketplace_id = ? AND is_active = 1
    `).bind(userId, marketplaceId).first<{ api_key: string }>();
    
    if (!apiKey) {
      return NextResponse.json(
        { error: 'API-ключ для Wildberries не найден или неактивен' },
        { status: 400 }
      );
    }

    // Получаем URL API для маркетплейса
    const marketplace = await env.DB.prepare(`
      SELECT api_url 
      FROM marketplaces 
      WHERE id = ?
    `).bind(marketplaceId).first<{ api_url: string }>();
    
    if (!marketplace) {
      return NextResponse.json(
        { error: 'Маркетплейс не найден' },
        { status: 404 }
      );
    }

    // Формируем запрос к API Wildberries
    const requestBody = {
      settings: {
        cursor: {
          limit
        }
      },
      filter: {
        withPhoto
      }
    };

    // Отправляем запрос к API Wildberries
    const response = await fetch(`${marketplace.api_url}/content/v2/get/cards/list`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': apiKey.api_key
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorData = await response.json();
      return NextResponse.json(
        { error: `Ошибка API Wildberries: ${JSON.stringify(errorData)}` },
        { status: response.status }
      );
    }

    const data = await response.json();
    
    // Логируем действие
    await env.DB.prepare(`
      INSERT INTO activity_logs (user_id, action_type, description) 
      VALUES (?, ?, ?)
    `).bind(
      userId, 
      'product_list_fetch',
      `Получен список товаров из Wildberries (${data.cards?.length || 0} товаров)`
    ).run();

    return NextResponse.json(data);
  } catch (error) {
    console.error('Error fetching product cards:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении списка товаров' },
      { status: 500 }
    );
  }
}

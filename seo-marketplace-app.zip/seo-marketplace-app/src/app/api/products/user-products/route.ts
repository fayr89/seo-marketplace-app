import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Получаем список товаров пользователя
    const products = await env.DB.prepare(`
      SELECT id, article, name, category, updated_at
      FROM products 
      WHERE user_id = ?
      ORDER BY updated_at DESC
    `).bind(userId).all();

    return NextResponse.json({
      products: products.results
    });
  } catch (error) {
    console.error('Error fetching user products:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении списка товаров' },
      { status: 500 }
    );
  }
}

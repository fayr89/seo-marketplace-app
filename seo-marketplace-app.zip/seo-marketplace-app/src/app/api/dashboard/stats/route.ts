import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Получаем общее количество товаров пользователя
    const totalProducts = await env.DB.prepare(`
      SELECT COUNT(*) as count 
      FROM products 
      WHERE user_id = ?
    `).bind(userId).first<{ count: number }>();
    
    // Получаем количество оптимизированных товаров (имеющих записи в истории SEO)
    const optimizedProducts = await env.DB.prepare(`
      SELECT COUNT(DISTINCT product_id) as count 
      FROM seo_history 
      WHERE product_id IN (SELECT id FROM products WHERE user_id = ?)
    `).bind(userId).first<{ count: number }>();
    
    // Получаем количество API-ключей пользователя
    const apiKeysCount = await env.DB.prepare(`
      SELECT COUNT(*) as count 
      FROM api_keys 
      WHERE user_id = ?
    `).bind(userId).first<{ count: number }>();
    
    // Получаем количество промптов пользователя
    const promptsCount = await env.DB.prepare(`
      SELECT COUNT(*) as count 
      FROM prompts 
      WHERE user_id = ?
    `).bind(userId).first<{ count: number }>();

    return NextResponse.json({
      totalProducts: totalProducts?.count || 0,
      optimizedProducts: optimizedProducts?.count || 0,
      apiKeysCount: apiKeysCount?.count || 0,
      promptsCount: promptsCount?.count || 0
    });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении статистики' },
      { status: 500 }
    );
  }
}

import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { getCloudflareContext } from "@/lib/cloudflare";
import bcrypt from "bcryptjs";

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        try {
          const { env } = getCloudflareContext();
          
          const user = await env.DB.prepare(
            "SELECT id, email, password, is_admin FROM users WHERE email = ?"
          ).bind(credentials.email).first();
          
          if (!user) {
            return null;
          }
          
          const isPasswordValid = await bcrypt.compare(
            credentials.password,
            user.password
          );
          
          if (!isPasswordValid) {
            return null;
          }
          
          // Логируем вход пользователя
          await env.DB.prepare(
            "INSERT INTO activity_logs (user_id, action_type, description) VALUES (?, ?, ?)"
          ).bind(
            user.id,
            "login",
            `Вход в систему: ${user.email}`
          ).run();
          
          return {
            id: user.id.toString(),
            email: user.email,
            isAdmin: user.is_admin === 1
          };
        } catch (error) {
          console.error("Auth error:", error);
          return null;
        }
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.isAdmin = user.isAdmin;
      }
      return token;
    },
    async session({ session, token }) {
      if (token && session.user) {
        session.user.id = token.id as string;
        session.user.isAdmin = token.isAdmin as boolean;
      }
      return session;
    }
  },
  pages: {
    signIn: "/auth/login",
  },
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 дней
  },
  secret: process.env.NEXTAUTH_SECRET || "your-secret-key",
};

export const handler = { GET: () => {}, POST: () => {} };

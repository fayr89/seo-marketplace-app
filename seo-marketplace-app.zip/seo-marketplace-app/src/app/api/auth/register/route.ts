import { getCloudflareContext } from '@/lib/cloudflare';
import { createUser } from '@/lib/auth/db';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { email, password, name } = await request.json();

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email и пароль обязательны' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const user = await createUser(env.DB, { email, password, name });

    if (!user) {
      return NextResponse.json(
        { error: 'Пользователь с таким email уже существует' },
        { status: 409 }
      );
    }

    return NextResponse.json({ success: true, user: { 
      id: user.id,
      email: user.email,
      name: user.name
    }});
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'Ошибка при регистрации' },
      { status: 500 }
    );
  }
}

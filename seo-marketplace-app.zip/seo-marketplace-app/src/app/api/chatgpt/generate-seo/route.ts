import { getCloudflareContext } from '@/lib/cloudflare';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      );
    }

    const { productData, promptId } = await request.json();
    
    if (!productData) {
      return NextResponse.json(
        { error: 'Данные о товаре обязательны' },
        { status: 400 }
      );
    }

    const { env } = getCloudflareContext();
    const userId = Number(session.user.id);
    
    // Получаем API-ключ пользователя для ChatGPT
    const apiKey = await env.DB.prepare(`
      SELECT api_key 
      FROM api_keys 
      WHERE user_id = ? AND key_type = 'chatgpt' AND is_active = 1
    `).bind(userId).first<{ api_key: string }>();
    
    if (!apiKey) {
      return NextResponse.json(
        { error: 'API-ключ для ChatGPT не найден или неактивен' },
        { status: 400 }
      );
    }

    // Получаем промпт пользователя
    let promptText;
    
    if (promptId) {
      const prompt = await env.DB.prepare(`
        SELECT prompt_text 
        FROM prompts 
        WHERE id = ? AND user_id = ?
      `).bind(promptId, userId).first<{ prompt_text: string }>();
      
      if (!prompt) {
        return NextResponse.json(
          { error: 'Промпт не найден' },
          { status: 404 }
        );
      }
      
      promptText = prompt.prompt_text;
    } else {
      // Используем промпт по умолчанию
      const defaultPrompt = await env.DB.prepare(`
        SELECT prompt_text 
        FROM prompts 
        WHERE user_id = ? AND is_default = 1
        LIMIT 1
      `).bind(userId).first<{ prompt_text: string }>();
      
      if (!defaultPrompt) {
        promptText = `Оптимизируй SEO для товара на Wildberries. 
Название товара: {title}
Описание товара: {description}
Ключевые слова: {keywords}
Категория: {category}

Предложи улучшенные варианты:
1. Название (до 100 символов)
2. Описание (до 1000 символов)
3. Ключевые слова (до 10 слов/фраз, разделенных запятыми)

Учитывай тренды поиска, используй ключевые слова разной частотности, структурируй описание на логические блоки.`;
      } else {
        promptText = defaultPrompt.prompt_text;
      }
    }
    
    // Заменяем плейсхолдеры в промпте реальными данными
    const filledPrompt = promptText
      .replace('{title}', productData.name || '')
      .replace('{description}', productData.description || '')
      .replace('{keywords}', productData.keywords || '')
      .replace('{category}', productData.category || '');
    
    // Отправляем запрос к API ChatGPT
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey.api_key}`
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'Ты - эксперт по SEO-оптимизации товаров на маркетплейсе Wildberries. Твоя задача - улучшить название, описание и ключевые слова товара для повышения его видимости в поиске.'
          },
          {
            role: 'user',
            content: filledPrompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1500
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return NextResponse.json(
        { error: `Ошибка API ChatGPT: ${JSON.stringify(errorData)}` },
        { status: response.status }
      );
    }

    const data = await response.json();
    const generatedContent = data.choices[0].message.content;
    
    // Логируем действие
    await env.DB.prepare(`
      INSERT INTO activity_logs (user_id, action_type, description) 
      VALUES (?, ?, ?)
    `).bind(
      userId, 
      'chatgpt_seo_generation',
      `Сгенерированы SEO-рекомендации для товара (ID: ${productData.id || 'новый'})`
    ).run();

    return NextResponse.json({
      success: true,
      generatedContent,
      promptUsed: filledPrompt
    });
  } catch (error) {
    console.error('Error generating SEO with ChatGPT:', error);
    return NextResponse.json(
      { error: 'Ошибка при генерации SEO-рекомендаций' },
      { status: 500 }
    );
  }
}

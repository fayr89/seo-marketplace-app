export const dynamic = 'force-dynamic';

import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Управление пользователями | SEO Wildberries',
  description: 'Административная панель для управления пользователями',
}

export default function UsersLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div>
      {children}
    </div>
  );
}

import { D1Database } from '@cloudflare/workers-types';
import bcrypt from 'bcryptjs';

export interface User {
  id: number;
  email: string;
  name: string | null;
  is_admin: boolean;
  created_at: string;
  last_login: string | null;
}

export interface UserCredentials {
  email: string;
  password: string;
  name?: string;
}

export async function getUserByEmail(db: D1Database, email: string): Promise<User | null> {
  const user = await db.prepare(
    'SELECT id, email, name, is_admin, created_at, last_login FROM users WHERE email = ?'
  ).bind(email).first<User>();
  
  return user || null;
}

export async function getUserById(db: D1Database, id: number): Promise<User | null> {
  const user = await db.prepare(
    'SELECT id, email, name, is_admin, created_at, last_login FROM users WHERE id = ?'
  ).bind(id).first<User>();
  
  return user || null;
}

export async function verifyUserCredentials(
  db: D1Database, 
  email: string, 
  password: string
): Promise<User | null> {
  const user = await db.prepare(
    'SELECT id, email, name, is_admin, created_at, last_login, password_hash FROM users WHERE email = ?'
  ).bind(email).first<User & { password_hash: string }>();
  
  if (!user) return null;
  
  const isValid = await bcrypt.compare(password, user.password_hash);
  if (!isValid) return null;
  
  // Update last login time
  await db.prepare(
    'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?'
  ).bind(user.id).run();
  
  // Return user without password hash
  const { password_hash, ...userWithoutPassword } = user;
  return userWithoutPassword;
}

export async function createUser(
  db: D1Database, 
  { email, password, name }: UserCredentials
): Promise<User | null> {
  // Check if user already exists
  const existingUser = await getUserByEmail(db, email);
  if (existingUser) return null;
  
  // Hash password
  const salt = await bcrypt.genSalt(10);
  const passwordHash = await bcrypt.hash(password, salt);
  
  // Create user
  const result = await db.prepare(
    'INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?) RETURNING id, email, name, is_admin, created_at, last_login'
  ).bind(email, passwordHash, name || null).first<User>();
  
  return result || null;
}

export async function getAllUsers(db: D1Database): Promise<User[]> {
  const users = await db.prepare(
    'SELECT id, email, name, is_admin, created_at, last_login FROM users ORDER BY created_at DESC'
  ).all<User>();
  
  return users.results;
}

export async function updateUserAdmin(
  db: D1Database, 
  userId: number, 
  isAdmin: boolean
): Promise<boolean> {
  const result = await db.prepare(
    'UPDATE users SET is_admin = ? WHERE id = ?'
  ).bind(isAdmin ? 1 : 0, userId).run();
  
  return result.success;
}

// Файл для исправления ошибок импорта
// Этот файл нужен только для успешной сборки проекта

import { authOptions } from "@/app/api/auth/[...nextauth]/route";
export { authOptions };

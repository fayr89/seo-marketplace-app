// Утилиты для работы с Cloudflare D1 и Workers

export function getCloudflareContext() {
  // @ts-ignore
  const env = process.env.NODE_ENV === 'development' ? { DB: global.DB } : { DB: process.env.DB };
  
  return { env };
}
